<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Initialize variables
$repairs = [];
$error_message = '';
$success_message = '';

// Status configurations
$STATUS_COLORS = [
    'W trakcie' => 'bg-yellow-100 text-yellow-800',
    'Oczekiwanie na części' => 'bg-orange-100 text-orange-800',
    'Gotowe' => 'bg-green-100 text-green-800',
    'Gotowa do odbioru' => 'bg-blue-100 text-blue-800',
    'Odebrane' => 'bg-purple-100 text-purple-800',
    'Archiwalne' => 'bg-gray-100 text-gray-800'
];

// Check for error or success messages in session
if(isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

if(isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

// Handle AJAX requests
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Handle status updates via AJAX
if($is_ajax && isset($_POST['update_status'])) {
    try {
        $repair_id = (int)$_POST['repair_id'];
        $new_status = $_POST['new_status'];
        
        $stmt = $pdo->prepare("UPDATE repairs SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $repair_id]);
        
        $stmt = $pdo->prepare("INSERT INTO repair_history (repair_id, status, notes) VALUES (?, ?, ?)");
        $stmt->execute([$repair_id, $new_status, "Status zmieniony na: " . $new_status]);
        
        exit(json_encode(['success' => true]));
    } catch(PDOException $e) {
        exit(json_encode(['error' => $e->getMessage()]));
    }
}

// Handle deletion
if(isset($_POST['delete_repair'])) {
    try {
        $repair_id = (int)$_POST['repair_id'];
        
        $stmt = $pdo->prepare("UPDATE repairs SET status = 'Usunięty' WHERE id = ?");
        $stmt->execute([$repair_id]);
        
        $stmt = $pdo->prepare("INSERT INTO repair_history (repair_id, status, notes) VALUES (?, 'Usunięty', ?)");
        $stmt->execute([$repair_id, "Naprawa oznaczona jako usunięta"]);
        
        $success_message = "Naprawa została oznaczona jako usunięta";
    } catch(PDOException $e) {
        $error_message = "Błąd podczas usuwania naprawy: " . $e->getMessage();
    }
}

// Handle search and filters
$search_type = $_GET['search_type'] ?? '';
$search_term = $_GET['search_term'] ?? '';

try {
    $query = "SELECT *, 
              CASE 
                WHEN option_expertise = 1 THEN 'Ekspertyza' 
                ELSE '' 
              END as expertise,
              CASE 
                WHEN option_repair = 1 THEN 'Naprawa' 
                ELSE '' 
              END as repair,
              CASE 
                WHEN option_supplies = 1 THEN 'Mat. eksploatacyjne' 
                ELSE '' 
              END as supplies
              FROM repairs WHERE status != 'Usunięty' AND status != 'Archiwalne' AND status != 'Odebrane'";
    $params = [];

    if (!empty($search_term)) {
        if ($search_type == "phone") {
            $query .= " AND phone_number = ?";
            $params[] = $search_term;
        } elseif ($search_type == "serial") {
            $query .= " AND serial_number = ?";
            $params[] = $search_term;
        }
    }

    $query .= " ORDER BY 
        CASE status
            WHEN 'W trakcie' THEN 1
            WHEN 'Oczekiwanie na części' THEN 2
            WHEN 'Gotowe' THEN 3
            WHEN 'Gotowa do odbioru' THEN 4
            ELSE 5
        END, created_at DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $repairs = $stmt->fetchAll();
    
    // Get count of archived and completed repairs
    $stmt = $pdo->query("SELECT COUNT(*) FROM repairs WHERE status IN ('Odebrane', 'Archiwalne') AND status != 'Usunięty'");
    $archived_count = $stmt->fetchColumn();
    
} catch(PDOException $e) {
    $error_message = "Błąd podczas pobierania danych: " . $e->getMessage();
}

// Helper function to get repair options as array
function getRepairOptions($repair) {
    $options = [];
    if (!empty($repair['expertise'])) $options[] = $repair['expertise'];
    if (!empty($repair['repair'])) $options[] = $repair['repair'];
    if (!empty($repair['supplies'])) $options[] = $repair['supplies'];
    return $options;
}

// Include the view
include 'dashboard_view.php';
?>