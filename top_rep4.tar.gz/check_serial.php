<?php
require_once 'config.php';

// Wyłącz wyświetlanie błędów na output
ini_set('display_errors', 0);
ini_set('log_errors', 1);
header('Content-Type: application/json');

try {
    if (!isset($_GET['serial']) || empty(trim($_GET['serial']))) {
        throw new Exception('Brak numeru seryjnego');
    }

    $serial = trim($_GET['serial']);
    if (!$mysqli) {
        throw new Exception('Błąd połączenia z bazą danych');
    }

    $stmt = $mysqli->prepare("SELECT phone_number FROM repairs WHERE serial_number = ? ORDER BY created_at DESC LIMIT 1");
    if (!$stmt) {
        throw new Exception('Błąd przygotowywania zapytania: ' . $mysqli->error);
    }

    if (!$stmt->bind_param('s', $serial)) {
        throw new Exception('Błąd bind_param: ' . $stmt->error);
    }

    if (!$stmt->execute()) {
        throw new Exception('Błąd execute: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $response = ['exists' => false];

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = [
            'exists' => true,
            'phone_number' => $row['phone_number']
        ];
    }

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTrace() // Tylko dla środowiska dev!
    ]);
}

if (isset($stmt)) $stmt->close();
if (isset($mysqli)) $mysqli->close();
?>