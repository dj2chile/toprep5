import React, { useState, useEffect } from 'react';
import { Camera } from 'lucide-react';

const RepairApp = () => {
    // [Previous state and handlers remain the same...]

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <style>
                {`
          @media print {
            .no-print {
              display: none !important;
            }
            .print-only {
              display: block !important;
            }
            .page-break {
              page-break-before: always;
            }
            body {
              width: 210mm;
              height: 297mm;
              margin: 0;
              padding: 20mm;
            }
            .qr-section img {
              display: block;
              margin: 0 auto;
            }
          }
          
          @media screen {
            .print-only {
              display: none !important;
            }
          }
          
          .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
          }
          
          .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 0.5rem;
            width: 90%;
            max-width: 500px;
          }
        `}
            </style>

            <form onSubmit={handleSubmit} className="space-y-6 bg-white shadow-lg rounded-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Dodaj nową naprawę</h2>

                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Model urządzenia</label>
                        <input
                            type="text"
                            name="device_model"
                            value={formData.device_model}
                            onChange={handleInputChange}
                            required
                            className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">Numer seryjny</label>
                        <div className="mt-1 flex gap-2">
                            <input
                                type="text"
                                name="serial_number"
                                value={formData.serial_number}
                                onChange={handleInputChange}
                                required
                                className="block w-full rounded-md border border-gray-300 p-2"
                            />
                            <button
                                type="button"
                                onClick={() => document.getElementById('fileInput').click()}
                                className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                            >
                                <Camera className="w-5 h-5 mr-2" />
                                Skanuj
                            </button>
                        </div>
                        <input
                            id="fileInput"
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={handleFileSelect}
                            className="hidden"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">Numer telefonu</label>
                        <input
                            type="tel"
                            name="phone_number"
                            value={formData.phone_number}
                            onChange={handleInputChange}
                            required
                            className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">NIP (opcjonalnie)</label>
                        <input
                            type="text"
                            name="nip"
                            value={formData.nip}
                            onChange={handleInputChange}
                            pattern="[0-9]{10}"
                            className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Przewody</label>
                        <div className="space-x-4">
                            <label className="inline-flex items-center">
                                <input
                                    type="checkbox"
                                    name="usb_cable"
                                    checked={formData.usb_cable}
                                    onChange={handleInputChange}
                                    className="rounded border-gray-300 text-pink-600"
                                />
                                <span className="ml-2">Kabel USB</span>
                            </label>
                            <label className="inline-flex items-center">
                                <input
                                    type="checkbox"
                                    name="power_cable"
                                    checked={formData.power_cable}
                                    onChange={handleInputChange}
                                    className="rounded border-gray-300 text-pink-600"
                                />
                                <span className="ml-2">Kabel zasilający</span>
                            </label>
                        </div>
                    </div>
                </div>

                {previewImage && (
                    <div className="mt-4">
                        <img src={previewImage} alt="Preview" className="max-w-md mx-auto" />
                    </div>
                )}

                {debug.length > 0 && (
                    <div className="mt-4 p-4 bg-gray-100 rounded-md text-sm font-mono">
                        {debug.map((message, index) => (
                            <div key={index}>{message}</div>
                        ))}
                    </div>
                )}

                <div className="mt-6">
                    <button
                        type="submit"
                        className="w-full inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-pink-600 hover:bg-pink-700"
                    >
                        Dodaj naprawę
                    </button>
                </div>
            </form>

            {/* Dodanie przycisku powrotu */}
            <div className="mt-4 text-center">
                <a
                    href="dashboard.php"
                    className="inline-block text-gray-600 hover:text-gray-800"
                >
                    &larr; Powrót do listy napraw
                </a>
            </div>
        </div>
    );
};

export default RepairApp;