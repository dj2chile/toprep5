<?php
function generateSecureString($length = 16) {
    return bin2hex(random_bytes(ceil($length / 2)));
}

session_start();
require_once 'config.php';

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['device_model'])) {
    try {
        // Generate secure status URL
        $statusUrl = generateSecureString();
        
        // Prepare statement - używamy oryginalnej struktury tabeli bez dodatkowych kolumn
        $stmt = $pdo->prepare("
            INSERT INTO repairs (
                device_model, serial_number, phone_number, 
                usb_cable, power_cable, nip, status_url, status,
                option_expertise, option_repair, option_supplies
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'W trakcie', ?, ?, ?)
        ");
        
        // Execute with form data
        $stmt->execute([
            $_POST['device_model'],
            $_POST['serial_number'],
            $_POST['phone_number'],
            isset($_POST['usb_cable']) ? 1 : 0,
            isset($_POST['power_cable']) ? 1 : 0,
            !empty($_POST['nip']) ? $_POST['nip'] : null,
            $statusUrl,
            isset($_POST['option_expertise']) ? 1 : 0,
            isset($_POST['option_repair']) ? 1 : 0,
            isset($_POST['option_supplies']) ? 1 : 0
        ]);
        
        $repairId = $pdo->lastInsertId();
        
        // Add initial history entry
        $stmt = $pdo->prepare("
            INSERT INTO repair_history (repair_id, status, notes)
            VALUES (?, 'W trakcie', 'Przyjęto do naprawy')
        ");
        $stmt->execute([$repairId]);
        
        // Redirect to repair details page with the repair ID
        header("Location: repair_details.php?id=" . $repairId);
        exit;
        
    } catch(PDOException $e) {
        $_SESSION['error_message'] = "Błąd podczas dodawania naprawy: " . $e->getMessage();
        header("Location: add_repair.php");
        exit;
    }
} else {
    header("Location: add_repair.php");
    exit;
}
?>