<?php
// Controller class for repair details - handles request processing

class RepairDetailsController {
    private $model;
    private $pdo;
    private $is_ajax;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->model = new RepairDetailsModel($pdo);
        $this->is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                         strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    // Generate CSRF token
    public function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    // Validate CSRF token
    public function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    // Log security event
    private function logSecurityEvent($message, $context = []) {
        $logEntry = date('Y-m-d H:i:s') . " | {$message}";
        
        if (!empty($context)) {
            $logEntry .= " | " . json_encode($context);
        }
        
        $logDir = __DIR__ . '/../logs';
        
        // Create logs directory if it doesn't exist
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        error_log($logEntry . PHP_EOL, 3, $logDir . '/security.log');
    }
    
    // Validate user authentication
    public function validateUserAccess() {
        if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
            $this->logSecurityEvent('Unauthorized access attempt');
            
            if ($this->is_ajax) {
                $this->sendJsonResponse(['error' => 'Unauthorized'], false);
            }
            
            return [
                'status' => 'error',
                'error_message' => 'Nieautoryzowany dostęp',
                'redirect' => 'login.php'
            ];
        }
        
        return ['status' => 'success'];
    }
    
    // Send JSON response
    public function sendJsonResponse($data, $success = true) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($success ? 200 : 400);
        exit(json_encode($data));
    }
    
    // Get initial options
    private function getInitialOptions($repair_id, $repair) {
        $initial_options_key = "initial_options_{$repair_id}";
        
        if (!isset($_SESSION[$initial_options_key])) {
            // First time viewing this repair, store the initial state
            $_SESSION[$initial_options_key] = array(
                'option_expertise' => $repair['option_expertise'] ?? 0,
                'option_repair' => $repair['option_repair'] ?? 0,
                'option_supplies' => $repair['option_supplies'] ?? 0,
                'usb_cable' => $repair['usb_cable'] ?? 0,
                'power_cable' => $repair['power_cable'] ?? 0
            );
        }
        
        return $_SESSION[$initial_options_key];
    }
    
    // Handle POST requests
    private function handlePostRequest($repair_id, $repair) {
        // Validate CSRF token
        if (!$this->validateCSRFToken($_POST['csrf_token'] ?? '')) {
            $this->logSecurityEvent('CSRF token validation failed');
            
            if ($this->is_ajax) {
                $this->sendJsonResponse(['error' => 'Nieprawidłowy token bezpieczeństwa'], false);
            }
            
            return [
                'status' => 'error',
                'error_message' => 'Błąd weryfikacji bezpieczeństwa. Spróbuj ponownie.'
            ];
        }
        
        try {
            switch (true) {
                case isset($_POST['update_option']):
                    $option_type = $_POST['option_type'];
                    $option_name = $_POST['option_name'];
                    $new_value = $_POST['value'] === 'true' ? 1 : 0;
                    
                    // Validate option
                    $this->model->validateOption($option_type, $option_name);
                    
                    // Update option
                    $this->model->updateOption($repair_id, $option_name, $new_value);
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                case isset($_POST['update_phone']):
                    $additional_phone = trim($_POST['additional_phone'] ?? '');
                    
                    // Validate phone number
                    $cleaned_phone = $this->model->validatePhoneNumber($additional_phone);
                    
                    // Update additional phone
                    $this->model->updateAdditionalPhone($repair_id, $cleaned_phone);
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                case isset($_POST['update_serial']):
                    $new_serial_number = trim($_POST['new_serial_number'] ?? '');
                    
                    if (empty($new_serial_number)) {
                        throw new Exception("Numer seryjny nie może być pusty");
                    }
                    
                    // Update serial number
                    $this->model->updateSerialNumber($repair_id, $new_serial_number, $repair['status'] ?? 'W trakcie');
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'success_message' => 'Numer seryjny został zaktualizowany',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                case isset($_POST['update_device_model']):
                    $new_device_model = trim($_POST['new_device_model'] ?? '');
                    
                    if (empty($new_device_model)) {
                        throw new Exception("Model urządzenia nie może być pusty");
                    }
                    
                    // Update device model
                    $this->model->updateDeviceModel($repair_id, $new_device_model, $repair['status'] ?? 'W trakcie');
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'success_message' => 'Model urządzenia został zaktualizowany',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                case isset($_POST['update_main_phone']):
                    $new_phone_number = trim($_POST['new_phone_number'] ?? '');
                    
                    // Validate phone number
                    $cleaned_phone = $this->model->validatePhoneNumber($new_phone_number);
                    
                    // Update phone number
                    $this->model->updatePhoneNumber($repair_id, $cleaned_phone, $repair['status'] ?? 'W trakcie');
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'success_message' => 'Numer telefonu został zaktualizowany',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                case isset($_POST['update_status_dropdown']):
                    $new_status = $_POST['new_status'];
                    $notes = substr(trim($_POST['notes'] ?? ''), 0, 500);
                    $send_sms = isset($_POST['send_sms']) && $_POST['send_sms'] === '1';
                    
                    // Update status
                    $this->model->updateStatus($repair_id, $new_status, $notes);
                    
                    // Redirect for SMS sending if requested
                    if ($send_sms) {
                        if ($this->is_ajax) {
                            $this->sendJsonResponse(['success' => true, 'redirect' => "send_status_sms.php?repair_id={$repair_id}&status={$new_status}"]);
                        }
                        
                        return [
                            'status' => 'success',
                            'redirect' => "send_status_sms.php?repair_id={$repair_id}&status={$new_status}"
                        ];
                    }
                    
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['success' => true]);
                    }
                    
                    return [
                        'status' => 'success',
                        'success_message' => 'Status został zaktualizowany',
                        'redirect' => "repair_details.php?id={$repair_id}"
                    ];
                
                default:
                    if ($this->is_ajax) {
                        $this->sendJsonResponse(['error' => 'Nieznane żądanie'], false);
                    }
                    
                    return [
                        'status' => 'error',
                        'error_message' => 'Nieznane żądanie'
                    ];
            }
        } catch (Exception $e) {
            // Log the error
            error_log("Update error: " . $e->getMessage());
            
            // Send error response
            if ($this->is_ajax) {
                $this->sendJsonResponse(['error' => $e->getMessage()], false);
            }
            
            return [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ];
        }
    }
    
    // Main method to handle requests
    public function handleRequest() {
        // Validate user access
        $result = $this->validateUserAccess();
        if ($result['status'] !== 'success') {
            return $result;
        }
        
        // Validate and sanitize repair ID
        $raw_repair_id = filter_input(INPUT_GET, 'id', FILTER_UNSAFE_RAW);
        
        try {
            $repair_id = $this->model->validateRepairId($raw_repair_id);
            
            // Process POST request if applicable
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $repair = $this->model->getRepair($repair_id);
                return $this->handlePostRequest($repair_id, $repair);
            }
            
            // For GET requests, fetch data for view
            $repair = $this->model->getRepair($repair_id);
            $history = $this->model->getHistory($repair_id);
            $related_repairs = $this->model->getRelatedRepairs($repair['phone_number'], $repair['serial_number'], $repair_id);
            $initial_options = $this->getInitialOptions($repair_id, $repair);
            $statusClasses = $this->model->getStatusClasses();
            $csrf_token = $this->generateCSRFToken();
            $settings = getCompanySettings($this->pdo);
            
            return [
                'status' => 'success',
                'data' => [
                    'repair' => $repair,
                    'repair_id' => $repair_id,
                    'history' => $history,
                    'related_repairs' => $related_repairs,
                    'initial_options' => $initial_options,
                    'statusClasses' => $statusClasses,
                    'csrf_token' => $csrf_token,
                    'settings' => $settings
                ]
            ];
            
        } catch (Exception $e) {
            if ($this->is_ajax) {
                $this->sendJsonResponse(['error' => $e->getMessage()], false);
            }
            
            return [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ];
        }
    }
}